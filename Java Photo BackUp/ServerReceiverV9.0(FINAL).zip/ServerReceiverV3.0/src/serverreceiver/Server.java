package serverreceiver;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author PRACHI
 */
public class Server {

    String userName;
    File logging;
    ServerSocket serverSocket;
    Socket clientSocket;
    BufferedReader bufferInput;
    BufferedWriter bufferOut;
    int total_images = 0;
     BufferedOutputStream serverStream ;

    public Server(Socket clientSocket, BufferedReader bufferInput, BufferedWriter bufferOut) {
        this.clientSocket = clientSocket;
        this.bufferInput = bufferInput;
        this.bufferOut = bufferOut;

    }

    void setUserName(String userName) {
        this.userName = userName;
        File file = new File("z:\\ARBA\\" + userName);
        // if(!Files.exists(FileSystems.getDefault().getPath("z:\\ARBA\\"+userName), LinkOption.NOFOLLOW_LINKS))
        if (!file.exists()) {

            file.mkdirs();

        } else {
            String[] files = file.list();
            total_images = files.length;

        }

        

    }
    
    void gettingStreams() throws FileNotFoundException{
        logging = new File("z:\\ARBA\\" + userName + "\\log" + total_images + ".jpg");
        serverStream = new BufferedOutputStream(new FileOutputStream(logging));
    }

    public void receiver() throws IOException, InterruptedException {
        int totalFilestoUpload;
        String response;
        System.out.println("Waiting for client to response.");
        //BufferedOutputStream 

        while (true) {
            a:
            if (bufferInput.ready()) {
                int value;
                response = bufferInput.readLine();
                if (response.equalsIgnoreCase("UPLOAD")) {
                    gettingStreams();
                    totalFilestoUpload = bufferInput.read();
                    System.out.println(totalFilestoUpload);
                    System.out.println("Yess receiving.");
//                    File file = new File("z:\\ARBA\\" + userName);
//                    // if(!Files.exists(FileSystems.getDefault().getPath("z:\\ARBA\\"+userName), LinkOption.NOFOLLOW_LINKS))
//                    if (!file.exists()) {
//
//                        file.mkdirs();
//
//                    } else {
//                        String[] files = file.list();
//                        total_images = files.length;
//
//                    }

                    do {
                        value = bufferInput.read();
                        if (value < 0 || value > 255) {

                            total_images++;
                            totalFilestoUpload--;

                            if (totalFilestoUpload == 0) {
                                break a;
                            }
                            logging = new File("z:\\ARBA\\" + userName + "\\log" + total_images + ".jpg");
                            serverStream = new BufferedOutputStream(new FileOutputStream(logging));

                        } else {

                            serverStream.write(value);

                        }
                    } while (true);
                } if(response.equalsIgnoreCase("RESTORE")) {
                    File file = new File("z:\\ARBA\\" + userName);
                    String[] fileNames;
                    fileNames = file.list();
                    int presentImages = fileNames.length;
                    ImageInputStream imageStream;
                    int tempBuffer;
                    // System.out.println(fileNames[0]);
                    if (presentImages != 0) {
                       // while (true) {
                       bufferOut.write("OK"+"\n");
                       bufferOut.flush();
                       bufferOut.write(presentImages);
                       bufferOut.flush();
                            for (String filename : fileNames) {
                                try {
                                    file = new File("z:\\ARBA\\" + userName + "\\"+filename);
                                    imageStream = ImageIO.createImageInputStream(file);
                                    System.out.println("z:\\ARBA\\" + userName + "\\"+filename);
                                    do {
                                        tempBuffer = imageStream.read();
                                        if (tempBuffer != -1) {
                                            bufferOut.write(tempBuffer);

                                        } else {

                                            bufferOut.write(256);
                                            bufferOut.flush();
                                            imageStream.close();

                                            break;
                                        }
                                    } while (true);

                                    System.out.printf("%d images left to restore. \n", --presentImages);
                                } catch (IOException ex) {
                                }
                            }
                            System.out.println("All Done...");
                            break a;

                       // }
                    }
                    else{
                        bufferOut.write("NOTOK"+"\n");
                        bufferOut.flush();
                        break a;
                    }

                }
                if(response.equalsIgnoreCase("LOGOUT")){
                    return;
                }
                  

            }
        }

    }

}
