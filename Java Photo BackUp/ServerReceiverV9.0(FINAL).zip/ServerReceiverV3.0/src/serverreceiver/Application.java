/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverreceiver;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author PRACHI
 */
public class Application {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        String userName;
        ServerSocket serverSocket;
        Socket clientSocket;
        BufferedReader bufferInput;
        BufferedWriter bufferout;
        String firstName,lastName,userID,password;
        DatabaseStore registrationData;
        
         serverSocket = new ServerSocket(8000);
        System.out.println("Server is waiting for a connection...");
        clientSocket = serverSocket.accept();
        System.out.println("Hey server stay alert. Connection established.");
        bufferInput = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        bufferout = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
        while(true){
            
        
        if(bufferInput.readLine().equalsIgnoreCase("LOGIN")){
            Autentication auth = new Autentication(clientSocket,bufferInput,bufferout);
            auth.setUserID();
            auth.setPassword();
            userName = auth.getUserID();
            if(auth.authentication()){
                Server myServer = new Server(clientSocket, bufferInput,bufferout);
               // myServer.getStreams();
               myServer.setUserName(userName);
                myServer.receiver();
                
            }
            
        }
        else{
          //  System.out.println("in Reg");
            firstName = bufferInput.readLine();
            System.out.println(firstName);
            lastName = bufferInput.readLine();
            System.out.println(lastName);
            userID = bufferInput.readLine();
            System.out.println(userID);
            password = bufferInput.readLine();
            System.out.println(password);
            
            registrationData = new DatabaseStore();
            registrationData.setFirstName(firstName);
            registrationData.setLastName(lastName);
            registrationData.setUserName(userID);
            registrationData.setPassword(password);
            boolean value = registrationData.validation();
            System.out.println(value);
            
            if(value){
                bufferout.write(1);
                bufferout.flush();
            }
            else{
                bufferout.write(0);
                bufferout.flush();
            }
            
        }
        
        
        
        }
        
        
        
    }
    
}
