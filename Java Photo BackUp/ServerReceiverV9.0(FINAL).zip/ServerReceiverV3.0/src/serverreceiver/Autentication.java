/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverreceiver;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author PRACHI
 */
public class Autentication {

    String userName;
    String password;
    ServerSocket serverSocket;
    Socket clientSocket;
    BufferedReader bufferInput;
    BufferedWriter bufferout;
    
    //void receiverUserID(Socket soc, )
    public Autentication(Socket socket,BufferedReader bufferInput, BufferedWriter bufferout) {
        this.clientSocket = socket;
        this.bufferInput = bufferInput;
        this.bufferout = bufferout;
    }
    
    
    
    void setUserID() throws IOException{
        userName = bufferInput.readLine();
        System.out.println("user: "+userName);
    }
    void setPassword() throws IOException{
        password = bufferInput.readLine();
        System.out.println(password);

    }
    
    String getUserID(){
        return userName;
    }
    
    
    
//    void setUserID(String userID) {
//        this.userName = userID;
//    }
//
//    void setPassword(String password) {
//        this.password = password;
//    }

    
    
    
    boolean authentication() throws IOException {
        String temp;
        Connection con = null;
        PreparedStatement prpstm = null;
        ResultSet resultset;
        String url = "jdbc:oracle:thin:@//localhost:1521/XE";
        String driver = "oracle.jdbc.driver.OracleDriver";
        String query = "Select password from Users where userName= ?";
        
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, "ashu", "ashu");
            prpstm = con.prepareStatement(query);
            prpstm.setString(1, userName);
            resultset = prpstm.executeQuery();
            
            if(resultset.next()==false) {
                bufferout.write(0);
                    bufferout.flush();
                    return false;
            }
            else{

                temp = resultset.getNString("password");
                System.out.println(temp);
                if (temp.equals(password)) {
                    bufferout.write(1);
                    bufferout.flush();
                    return true;
                }
                else{
                    bufferout.write(0);
                    bufferout.flush();
                    return false;
                  
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        finally {
            try {
                if (prpstm != null) {
                    prpstm.close();
                }
                if (con != null) {
                    con.close();
                }
            }
            catch (SQLException e) {
            }
        }
        
       bufferout.write(0);
       return false;
        

    }
}
