/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverreceiver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author PRACHI
 */
public class DatabaseStore {
    Connection con = null;
    PreparedStatement prpstm;
    String firstName;
    String lastName;
    String userName;
    String password;
    
    
  // public DatabaseStore(S)
    
    void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    void setLastName(String lastName){
        this.lastName = lastName;
    }
    
    void setUserName(String userName){
        this.userName = userName;
    }
    void setPassword(String password){
        this.password = password;
    }
    
    
    boolean validation(){
        
        String driver = "oracle.jdbc,driver.OracleDriver";
        String url = "jdbc:oracle:thin:@//localhost:1521/XE";
        String query = "insert into Users values(?,?,?,?)";
        try{
        con = DriverManager.getConnection(url, "ashu","ashu");
        prpstm = con.prepareStatement(query);
        prpstm.setString(1, firstName);
        prpstm.setString(2, lastName);
        prpstm.setString(3, userName);
        prpstm.setString(4, password);
            return !prpstm.execute();
            

        
        }catch(SQLException e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        
        
        return false;
    }
    
    
    
}
