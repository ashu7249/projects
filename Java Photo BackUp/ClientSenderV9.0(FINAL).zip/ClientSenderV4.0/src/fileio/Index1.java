/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author PRACHI
 */
public class Index1 {

    JLabel label;
    JFrame startFrame;
    JButton button;
    Container container;
    Client client;

    public Index1() {
        startFrame = new JFrame();
        button = new JButton("START");

    }

    void launchFrame() {
        //container = startFrame.getContentPane();
        label = new JLabel(new ImageIcon("back.jpg"));
        //label.setIcon();
        //label.setOpaque(false);
        button.setPreferredSize(new Dimension(100, 50));
        label.setLayout(new CardLayout(200, 220));
        button.setBackground(Color.getHSBColor(13, 55, 13));
        label.add(button);
        button.setFocusable(false);

        startFrame.setContentPane(label);

        button.addActionListener(new ActionListener() {
            Socket mySocket;
            BufferedWriter bufferout;
            BufferedReader bufferInput;

            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    mySocket = new Socket("localhost", 8000);
                    bufferout = new BufferedWriter(new OutputStreamWriter(mySocket.getOutputStream()));
                    bufferInput = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
                } catch (IOException ex) {
                    Logger.getLogger(Index1.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                new Login(mySocket,bufferInput,bufferout).setVisible(true);
                startFrame.dispose();
//                try {
//                    client = new Client();
//                    client.getStreams();
//                } catch (IOException ex) {
//                    Logger.getLogger(Index1.class.getName()).log(Level.SEVERE, null, ex);
//                }

            }
        });

        //container.add(button);
        //startFrame.add(container);
        startFrame.setBackground(Color.BLACK);
        startFrame.setResizable(false);
        startFrame.setLocation(380, 130);
        startFrame.setPreferredSize(new Dimension(580, 500));
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.pack();
        startFrame.setVisible(true);

    }

}
