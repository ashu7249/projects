package fileio;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author PRACHI
 */
public class Client {

    ImageIcon frameIcon;
    JLabel cloudLabel;
    BoxLayout mgr;
    JPanel myPanel;
    JButton uploadButton;
    JButton restoreButton;
    JFileChooser myFileSelect;
    BufferedReader bufferin;
    BufferedWriter bufferout;
    JFrame myFrame;
    Socket serverSocket;
    JButton logOut;

    public Client(Socket socket, BufferedReader bufferin, BufferedWriter bufferout) throws IOException {
        mgr = new BoxLayout(myPanel, BoxLayout.PAGE_AXIS);
        myFrame = new JFrame("CLOUD");
        myPanel = new JPanel();
        uploadButton = new JButton("UPLOAD");
        restoreButton = new JButton("RESTORE");
        myFileSelect = new JFileChooser();
        this.serverSocket = socket;
        cloudLabel = new JLabel();
        frameIcon = new ImageIcon("cloud.jpg");
        this.bufferout = bufferout;
        this.bufferin = bufferin;
        logOut = new JButton("LOG OUT");
    }

    void launchFrame() {

        myFrame.setIconImage(frameIcon.getImage());
        myPanel.setBackground(Color.lightGray);
        myPanel.add(cloudLabel);
        cloudLabel.setIcon(new ImageIcon("index.jpg"));
        myPanel.add(uploadButton);
        myPanel.add(restoreButton);
        myPanel.add(logOut);
        
        
        logOut.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                 try {
                        bufferout.write("LOGOUT" + "\n");
                        bufferout.flush();
                    } catch (IOException ex) {
                        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                new Login(serverSocket,bufferin,bufferout).setVisible(true);
                myFrame.dispose();
            }
        });
        
        
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int tempBuffer, imageNoUploadSuccessfully = 0, totalFilestoUpload;
                File[] selectedFiles;
                FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF Images", "jpg", "gif");
                myFileSelect.setFileFilter(filter);
                myFileSelect.setMultiSelectionEnabled(true);
                if (myFileSelect.showOpenDialog(myPanel) == JFileChooser.APPROVE_OPTION) {
                    try {
                        bufferout.write("UPLOAD" + "\n");
                        bufferout.flush();
                    } catch (IOException ex) {
                        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ImageInputStream imageStream;

                    selectedFiles = myFileSelect.getSelectedFiles();
                    totalFilestoUpload = selectedFiles.length;
                    try {
                        bufferout.write(totalFilestoUpload);
                        bufferout.flush();

                    } catch (IOException ex) {
                        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    for (File selected : selectedFiles) {
                        try {
                            imageStream = ImageIO.createImageInputStream(selected);
                            //getStreams();

                            do {
                                tempBuffer = imageStream.read();
                                if (tempBuffer != -1) {
                                    bufferout.write(tempBuffer);

                                } else {

                                    bufferout.write(256);
                                    bufferout.flush();
                                    imageStream.close();

                                    break;
                                }
                            } while (true);

                            System.out.printf("Image no %d uploaded successfully. \n", ++imageNoUploadSuccessfully);
                        } catch (IOException ex) {
                        }
                    }
                    JOptionPane.showMessageDialog(myFrame, "Images Uploaded Successfully.", "UPLOAD STATUS", JOptionPane.INFORMATION_MESSAGE);
                    // JOptionPane.showm
                } else {
                    System.out.println("User says cancel.");
                }

            }

        });

        restoreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int totalImages, value;
                String logging = File.listRoots()[0].getAbsolutePath() + "\\ARBA\\RestoreFile";
                File file = new File(logging);
                if (!file.exists()) {
                    file.mkdirs();
                }
                try {
                    bufferout.write("RESTORE" + "\n");
                    bufferout.flush();

                    if (bufferin.readLine().equalsIgnoreCase("OK")) {
                        totalImages = bufferin.read();
                        BufferedOutputStream serverStream = new BufferedOutputStream(new FileOutputStream(logging+"\\log"+totalImages+".jpg"));
                       // while (totalImages != 0) {
                            a:
                            do {
                                value = bufferin.read();
                                if (value < 0 || value > 255) {

                                    --totalImages;

                                    if (totalImages == 0) {
                                        break a;
                                    }
                                    file = new File(logging+"\\log" + totalImages + ".jpg");
                                    serverStream = new BufferedOutputStream(new FileOutputStream(file));

                                } else {

                                    serverStream.write(value);

                                }
                            } while (true);
                       // }
                       JOptionPane.showMessageDialog(myFrame,"Images Restored successfully.","Succes", JOptionPane.INFORMATION_MESSAGE);
                    }
                    else{
                        JOptionPane.showMessageDialog(myFrame,"No images uploaded yet","ERROR", JOptionPane.ERROR_MESSAGE);
                        
                    }
                } catch (IOException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
        
        
        

        myFrame.add(myPanel);
        myFrame.setLocation(450, 200);
        //       myFrame.setDefaultLookAndFeelDecorated(true);
        myFrame.setPreferredSize(new Dimension(400, 400));
       // myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setResizable(false);
        myFrame.pack();
        myFrame.setVisible(true);

    }

    

}
