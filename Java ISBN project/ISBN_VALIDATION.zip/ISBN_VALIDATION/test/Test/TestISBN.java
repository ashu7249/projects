/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import isbn_validation.ISBN;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


/**
 *
 * @author Ashutosh Kedar
 */
public class TestISBN {
    ISBN testObject ;
    
    public TestISBN() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
        
    }
    
    @Before
    public void setUp() {
        
    }
    
    @After
    public void tearDown() {
    }
    
    
    /**
     * Test the object for the default initialization.
     */
    @Test
     public void no_parameter_object_creation_test() {
         testObject = new ISBN();
         assertNotEquals(null ,testObject);
         //fail("Object Not Created: FAILED.");             
     }
    
     /**
      * Test the parameterized constructor with both correct as well as with wrong parameter.
      * 
      * @throws IllegalArgumentException: If the format of the number is not correct.
      */
     @Test(expected=IllegalArgumentException.class)
     public void parameterised_object_creation_test(){
     
         testObject = new ISBN("123-34-1244-3");
         assertNotEquals(null, testObject);         
         testObject = new ISBN("Test123-S");     
//       fail("Parameterised Object Creation Fail: FAILED.");
         
     }
     
     /**
      * Test if the input number does not contains an alphabetic character.
      */
     @Test
     public void ISBN_Alphabetic_Type_Validation_test_Expected_False(){
         
         //testing with alphabets
         assertEquals(false ,ISBN.correct_format_ISBN("13t-34-1d4-354"));  
         //testing with special character
         assertEquals(false ,ISBN.correct_format_ISBN("133-3t-16@-4")); 
         
 //      fail("ISBN numeric type validation Fail: FAILED");
 
     }
     
     /**
      * Test if the input number is exact 10 or 13 digit ISBN number.
      */
     
     @Test
     public void ISBN_Length_Validation_test_Expected_False(){
         
           //ISBN number greater then 10 digits and less then 13 digits
         assertEquals(false,ISBN.correct_format_ISBN("123-34-56-254-56"));
         //ISBN number greater than 13 digits
         assertEquals(false,ISBN.correct_format_ISBN("123-34-56-2564-5645"));
         //ISBN number less than 10 digit test
         assertEquals(false,ISBN.correct_format_ISBN("123-34-56"));
         //ISBN number of length 13 digits
         assertEquals(true,ISBN.correct_format_ISBN("978-0-306-40615-7"));
         //ISBN number of length 10 digits
         assertEquals(true,ISBN.correct_format_ISBN("960-425-059-0"));
//       fail("ISBN length validation Fail: FAILED");

     } 
     
     /**
      * Tests the validation of the the ISBN number inside the object.
      */
     @Test
     public void valid_13_DIGIT_ISBN_test_Expected_True(){
         
         testObject = new ISBN("978-0-306-40615-7");        
         assertEquals(true,testObject.is_ISBN_Valid());
         
     }
     
     /**
      * Tests whether the number is a 10 digit ISBN number.
      */
     @Test 
     public void test_type_Of_ISBN_number(){
         
         testObject = new ISBN("960-425-059-0");
         assertEquals(true,testObject.is_ISBN_TEN_DIGIT());
//         fail("Checking the ISBN type failed. FAILED.");

     }
     
     /**
      * Tests the validation of the the ISBN number inside the object.
      * 
      */
     
      @Test
      public void valid_10_DIGIT_ISBN_test_Expected_True(){
//          fail("Ten Digit ISBN test failed. FAILED.");
            testObject = new ISBN("85-359-0277-5");
            assertEquals(true,testObject.is_ISBN_Valid());
        
      }
      
      /**
       * Tests the validation of the the ISBN number inside the object having last digit as 'X' (which signifies numeric value 10).
       */
      @Test
      public void valid_ISBN_with_last_digit_as_X(){
           testObject = new ISBN("0-8044-2957-X");
//           System.out.println(testObject.ISBN_list);
           assertEquals(true,testObject.is_ISBN_Valid());
           
//          fail("Validating ISBN with last digit as 'X' failed. FAILED");

         }
      
      /**
       * Tests the getters for the ISBN object
       */
      @Test 
      public void test_getters(){
          testObject = new ISBN("0-8044-2957-X");
          
          assertEquals("0-8044-2957-X",testObject.get_ISBN());
      }
      
      /**
       * Tests the validation of the 10 digit ISBN number inside the object.
       */
      @Test
      public void ISBN_Number_of_Digits_test(){

//            fail("ISBN number of digits test failed. FAILED.");
            testObject = new ISBN("99921-58-10-7");
            assertEquals(true,testObject.is_ISBN_TEN_DIGIT());
      }
     
}