/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isbn_validation;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * A class that validates the ISBN number provided.
 * @author Ashutosh Kedar
 */
public class ISBN {
    
    private static final Pattern ISBN_REGX_FOR_10_DIGIT = Pattern.compile("^(\\d+)-{1}(\\d+)-{1}(\\d+)-{1}(\\d+)$");
    private static final Pattern ISBN_REGX_FOR_13_DIGIT = Pattern.compile("^(\\d+)-{1}(\\d+)-{1}(\\d+)-{1}(\\d+)-{1}(\\d+)$");
    private String ISBN;
    private List <String> ISBN_list = new ArrayList();
    
    private final Function <List<String>,Boolean> ISBN_checksum_test_for_13_digit = (list_of_ISBN) -> {                                                                                    
                                                                                        int firstMultiple = 1;
                                                                                        int secondMultiple = 3;
                                                                                        boolean factor = true;
                                                                                        int sum = 0;
                                                                                        for(String achar : list_of_ISBN){
                                                                                            if(factor){
                                                                                                sum += Integer.parseInt(achar) * firstMultiple ;
                                                                                                factor = false;
                                                                                            }else{
                                                                                                sum += Integer.parseInt(achar) * secondMultiple ;
                                                                                                factor = true;
                                                                                            }
                                                                                        }
        //                                                                                    System.out.println(sum);
                                                                                        return (sum % 10) == 0 ; 
                                                                                    };  
    
    private final Function <List<String>,Boolean> ISBN_checksum_test_for_10_digit = (list_of_ISBN) -> {                         
                                                                                            int multiple = 1;                                                                                                                                                                    
                                                                                            int sum = 0;                                                                                    
                                                                                            if(list_of_ISBN.remove("X")){
                                                                                                list_of_ISBN.add("10");
                                                                                            }
                                                                                             for(String achar : list_of_ISBN){                                                                                                                                                                              
                                                                                                    sum += Integer.parseInt(achar) * multiple++ ;
                                                                                             }                                                                                    
                                                                                            // System.out.println(list_of_ISBN+ " "+ sum);                                                                                  
                                                                                            return (sum % 11) == 0 ; 
                                                                                        }; 
    /**
     * This is an default constructor which initialize the ISBN 
     * with 10 digits zero.
     */
  
    public ISBN(){
       ISBN = "0000-000-00-0";
       feed_ISBN_number_list("0000-000-00-0");
    }
    /**
     * A single parameter constructor that that initializes the object with the passes ISBN number.
     * 
     * @param isbnNumber:String representing the ISBN number
     * @throws IllegalArgumentException : When the passed string is not in proper format.
     * @see isbn_validation.ISBN#correct_format_ISBN(java.lang.String) Static method to check the format of ISBN number correct_format_ISBN(String)
     */
    public ISBN(String isbnNumber) throws IllegalArgumentException{
        
        if(!correct_format_ISBN(isbnNumber)){
            throw new IllegalArgumentException();
        }else{
            ISBN = isbnNumber;
            feed_ISBN_number_list(isbnNumber);
        }
                
    }
    
    private void feed_ISBN_number_list(String ISBN_number){
            //ISBN_number = fixing_last_digit(ISBN_number);
            for( Character aChar : ISBN_number.toCharArray()){  
                if(aChar != '-'){
                 ISBN_list.add(aChar.toString());      
                }
            } 
    }
    
    private static String fixing_last_digit(String ISBN_number){
        if(ISBN_number.endsWith("X")){          
                ISBN_number = ISBN_number.replace("X","10");// "10");
            }
        return ISBN_number;
    }
    /**
     * A static method that confirms the format of the passed string to the ISBN number format.
     * 
     * @param ISBN_to_check:Input String to check the ISBN format of the number
     * @return String:Returns true if the number is it proper ISBN format, but does not guarantees the validation of the ISBN number
     * @see isbn_validation.ISBN#is_ISBN_Valid()  To check the validation of the ISBN number: is_ISBN_Valid()
     */
    public static boolean correct_format_ISBN(String ISBN_to_check){
        Matcher matcher;
        if(ISBN_to_check.length() == 17 ){       
            matcher = ISBN_REGX_FOR_13_DIGIT.matcher(ISBN_to_check);
//            System.out.println(ISBN);
        }else{
            if(ISBN_to_check.length() == 13 || ISBN_to_check.length() == 14){
//                System.out.println(ISBN_to_check +" "+ ISBN_REGX_FOR_10_DIGIT.matcher(ISBN_to_check).matches());                
                matcher = ISBN_REGX_FOR_10_DIGIT.matcher(fixing_last_digit(ISBN_to_check));
            }
            else{
                return false;
            }
            
        }        
        return  matcher.matches();
        
    }
    /**
     * This is a getter method for the ISBN number inside the object.
     * 
     * @return String: Returns the ISBN number stored. 
     */
    
     public String get_ISBN() {
        return ISBN;        
    }
     
     /**
      * This instance method performs the validation on the ISBN number stored in the object.Does not gurantees that the provided ISBN is 
      * allocated to a book, publication etc.
      * 
      * @return : Returns true if the ISBN stored inside the object is a valid ISBN number,
      * 
      */
   
     public boolean is_ISBN_Valid(){
            
            if(is_ISBN_TEN_DIGIT()){
//                System.out.println(ISBN_list);
                return ISBN_checksum_test_for_10_digit.apply(ISBN_list); 
                
            }else{
               return ISBN_checksum_test_for_13_digit.apply(ISBN_list); 
            }      
            
     }

    public boolean is_ISBN_TEN_DIGIT() {
         return ISBN.toCharArray().length == 13;
    }

    

}
